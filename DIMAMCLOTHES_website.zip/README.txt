DIMAMCLOTHES website starter

PREVIEW
1. Open index.html in a web browser.
2. Internet is needed to load the sample Unsplash photos.

CUSTOMIZE
- Search for DIMAMCLOTHES in index.html to edit brand text.
- Replace the sample image URLs in the CSS with your own image URLs.
- Replace hello@dimamclothes.com with your real business email if different.

PUBLISH FREE WITH GITHUB PAGES
1. Create a GitHub account at https://github.com/
2. Create a new PUBLIC repository (for example, dimamclothes).
3. Upload index.html to the root of the repository.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select main and /(root), then Save.
7. GitHub will provide a public website address after deployment.

NOTE
This is a static showcase website, not a full online shop yet. It has no checkout, inventory, order management or payment processing. The sample email link and placeholder product labels should be updated before launch.
